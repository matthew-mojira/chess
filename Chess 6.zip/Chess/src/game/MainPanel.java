package game;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.UIManager;

import pieces.Bishop;
import pieces.King;
import pieces.Knight;
import pieces.Lancer;
import pieces.Pawn;
import pieces.Queen;
import pieces.Rook;
import pieces.Side;

public class MainPanel extends JPanel {

	private static final long serialVersionUID = 1L;

	public MainPanel() {

		try {
			UIManager.setLookAndFeel( UIManager.getCrossPlatformLookAndFeelClassName() );
		} catch (Exception e) {
			e.printStackTrace();
		}

		setLayout(new BorderLayout());

		add(new GridLayoutPanel(), BorderLayout.CENTER);

		add(new JPanel() {
			{
				setLayout(new GridLayout(1, 1));
				JButton reset = new JButton("Reset");
				reset.addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {

						Pawn whitePawn = new Pawn(Side.WHITE);
						Pawn blackPawn = new Pawn(Side.BLACK);
						Rook whiteRook = new Rook(Side.WHITE);
						Rook whiteRook2 = new Rook(Side.WHITE);
						Rook blackRook = new Rook(Side.BLACK);
						Rook blackRook2 = new Rook(Side.BLACK);
						Bishop whiteBishop = new Bishop(Side.WHITE);
						Bishop blackBishop = new Bishop(Side.BLACK);
						Queen whiteQueen = new Queen(Side.WHITE);
						Queen blackQueen = new Queen(Side.BLACK);
						Knight whiteKnight = new Knight(Side.WHITE);
						Knight blackKnight = new Knight(Side.BLACK);
						Lancer whiteLancer = new Lancer(Side.WHITE);
						Lancer blackLancer = new Lancer(Side.BLACK);
						Chess.board = new Board();
						Chess.getBoard().set(whitePawn, 6, 0);
						Chess.getBoard().set(whitePawn, 6, 1);
						Chess.getBoard().set(whitePawn, 6, 2);
						Chess.getBoard().set(whitePawn, 6, 3);
						Chess.getBoard().set(whitePawn, 6, 4);
						Chess.getBoard().set(whitePawn, 6, 5);
						Chess.getBoard().set(whitePawn, 6, 6);
						Chess.getBoard().set(whitePawn, 6, 7);
						Chess.getBoard().set(blackPawn, 1, 0);
						Chess.getBoard().set(blackPawn, 1, 1);
						Chess.getBoard().set(blackPawn, 1, 2);
						Chess.getBoard().set(blackPawn, 1, 3);
						Chess.getBoard().set(blackPawn, 1, 4);
						Chess.getBoard().set(blackPawn, 1, 5);
						Chess.getBoard().set(blackPawn, 1, 6);
						Chess.getBoard().set(blackPawn, 1, 7);
						Chess.getBoard().set(whiteRook, 7, 0);
						Chess.getBoard().set(whiteRook2, 7, 7);
						Chess.getBoard().set(blackRook, 0, 0);
						Chess.getBoard().set(blackRook2, 0, 7);
						Chess.getBoard().set(blackBishop, 0, 2);
						Chess.getBoard().set(blackBishop, 0, 5);
						Chess.getBoard().set(whiteBishop, 7, 2);
						Chess.getBoard().set(whiteBishop, 7, 5);
						Chess.getBoard().set(whiteQueen, 7, 3);
						Chess.getBoard().set(blackQueen, 0, 3);
						Chess.getBoard().set(whiteKnight, 7, 1);
						Chess.getBoard().set(whiteKnight, 7, 6);
						Chess.getBoard().set(blackKnight, 0, 1);
						Chess.getBoard().set(blackKnight, 0, 6);
						Chess.getBoard().set(new King(Side.WHITE), 7, 4);
						Chess.getBoard().set(new King(Side.BLACK), 0, 4);
						GridLayoutPanel.setBoardPieces();
						GridLayoutPanel.color = Color.getHSBColor((float)Math.random(), 0.25f, 1.0f);
						GridLayoutPanel.resetBackgroundColors();


					}

				});


				JButton undo = new JButton("Undo");
				undo.addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
						Chess.getBoard().undo();
						GridLayoutPanel.setBoardPieces();
					}

				});


				JButton computer = new JButton("Computer turn");
				computer.addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {


						Chess.chessEngine.makeAMove();

						GridLayoutPanel.resetBackgroundColors();
						GridLayoutPanel.setBoardPieces();
						

					}
				});
				



				add(reset);
				// add(undo);
				// TODO: doesn't work
				add(computer);
				// add(automatic);
			}
		}, BorderLayout.SOUTH);
		
		







	}

}
