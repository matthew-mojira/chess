package game;

import java.awt.Color;
import java.awt.Insets;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JPanel;

import pieces.Piece;

public class GridLayoutPanel extends JPanel {

	static ArrayList<JButton> buttons;
	static Color color;
	int firstMoveX;
	int firstMoveY;

	public GridLayoutPanel() {
		setLayout(new GridLayout(8, 8));

		buttons = new ArrayList<>();

		color = Color.getHSBColor((float) Math.random(), 0.25f, 1.0f);

		firstMoveX = -1;
		firstMoveY = -1;

		for (int i = 0; i < 64; i++) {
			JButton button = new JButton("\u2656"); // (char)('A' + j) + (String.valueOf(8 - i)) +

			button.setFont(new Font("Arial Unicode MS", Font.PLAIN, fontSize()));
			button.setMargin(new Insets(0, 0, 0, 0));
			button.setOpaque(true);

			buttons.add(button);

			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent event) {

					int indexX = buttons.indexOf(button) / 8;
					int indexY = buttons.indexOf(button) % 8;

					System.out.println(indexX + " " + indexY);

					if (firstMoveX == -1 && firstMoveY == -1) {
						firstMoveX = indexX;
						firstMoveY = indexY;

						button.setBackground(Color.YELLOW);
					} else {
						if (!(Chess.getBoard().move(firstMoveX, firstMoveY, indexX, indexY))) {
							System.out.println("Move invalid.");
							// System.out.println(indexX + " " + indexY);
							// System.out.println(firstMoveX + " " + firstMoveY);
							setBoardPieces();
						} else {
							// COMPUTER MOVE autoamtic

//							Chess.chessEngine.makeAMove();
//
//							GridLayoutPanel.resetBackgroundColors();
//							GridLayoutPanel.setBoardPieces();

						}

						firstMoveX = -1;
						firstMoveY = -1;

						System.out.println(Chess.getBoard());

						resetBackgroundColors();

					}

					// System.out.println("What button is this?" + buttons.indexOf(button) / 8 +
					// buttons.indexOf(button) % 8);

					setBoardPieces();
				}
			});

			add(button);
			resetBackgroundColors();
			setBoardPieces();

		}
	}

	/**
	 * Sets all tiles to the background color checkerboard pattern.
	 */
	static void resetBackgroundColors() {
		int i = 0;

		for (JButton b : buttons) {
			i += (i % 9 == 0) ? 2 : 1;
			if (i % 2 == 0) {
				b.setBackground(Color.WHITE);
			} else {
				b.setBackground(color);
			}
		}
	}

	/**
	 * Refreshes all the board pieces so each tile displays what piece is on it.
	 */
	static void setBoardPieces() {
		Iterator<Piece> it = Chess.getBoard().iterator();
		boolean check = Chess.board.isInCheck();
		for (JButton b : buttons) {
			String sett;
			try {
				Piece next = it.next();
				sett = next.toString();
				// highlight the king in check
				if (check && next instanceof pieces.King && next.getSide() == Chess.board.sideToMove) {
					b.setBackground(Color.RED);
				}
			} catch (NullPointerException e) {
				sett = "";
			}
			b.setText(sett);
		}
		
		// set title
		
		Chess.frame.setTitle("Chess: Move " + Chess.board.moveCounter + " / " + Chess.board.sideToMove + " to move");

	}

	public int fontSize() {
		return 40;
	}
}
