package game;

import java.util.Arrays;

import pieces.Piece;
import pieces.Side;

/**
 * A collection displaying possible moves for a chess piece on the chess board.
 * <p>
 * This class wraps around an array of <Movement> which is the same size as the
 * chess board. An instance of this class should be created when a piece is
 * trying to move. Every entry in the array governs for that moment what kind of
 * move can be made with that piece.
 * 
 * @author Matthew
 *
 */
public class Movements {

	Movement[][] board;

	/**
	 * Types of board moves that a piece can make.
	 * 
	 * @author Matthew
	 *
	 */
	public enum Movement {
		ILLEGAL, LEGAL, CAPTURE, CASTLE, CHECK, CHECKMATE, EN_PASSANT, PROMOTE, CAN_BE_EN_PASSANTED;
	}

	/**
	 * Initializes an array of movements where all are <ILLEGAL>.
	 */
	public Movements() {
		board = new Movement[Board.BOARD_SIZE][Board.BOARD_SIZE];
		for (int i = 0; i < Board.BOARD_SIZE; i++) {
			for (int j = 0; j < Board.BOARD_SIZE; j++) {
				board[i][j] = Movement.ILLEGAL;
			}
		}
	}

	/**
	 * Sets a kind of movement on the board.
	 * 
	 * @param rank
	 * @param file
	 * @param m
	 */
	public void set(int rank, int file, Movement m) {
		try {
			board[rank][file] = m;
		} catch (ArrayIndexOutOfBoundsException e) {

		}
	}

	public boolean checkLegalMove(int rank, int file) {
		return board[rank][file] != Movement.ILLEGAL;
	}

	public Movement get(int rank, int file) {
		return board[rank][file];
	}

	public Movement[][] getBoard() {
		return board;
	}

	public boolean hasCheck() {
		for (int i = 0; i < Board.BOARD_SIZE; i++) {
			for (int j = 0; j < Board.BOARD_SIZE; j++) {
				if (board[i][j] == Movement.CHECK) {
					System.out.print(Arrays.deepToString(board));
					return true;

				}
			}
		}
		return false;
	}

}
