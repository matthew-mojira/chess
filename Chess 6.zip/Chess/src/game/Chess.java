package game;

import javax.swing.JFrame;
import javax.swing.WindowConstants;

import engines.*;
import pieces.*;

public class Chess {

	static Board board;
	static Chessable chessEngine;
	static JFrame frame;

	public static void createAndShowGUI() {
		frame = new JFrame("Chess");
		frame.setContentPane(new MainPanel());
		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		//		frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		frame.setSize(430, 450);
		//		frame.setResizable(false);
		frame.setVisible(true);
	}

	public static void main(String[] args) {

		chessEngine = new RandomEngine2();



		Pawn whitePawn = new Pawn(Side.WHITE);
		Pawn blackPawn = new Pawn(Side.BLACK);
		Rook whiteRook = new Rook(Side.WHITE);
		Rook whiteRook2 = new Rook(Side.WHITE);
		Rook blackRook = new Rook(Side.BLACK);
		Rook blackRook2 = new Rook(Side.BLACK);
		Bishop whiteBishop = new Bishop(Side.WHITE);
		Bishop blackBishop = new Bishop(Side.BLACK);
		Queen whiteQueen = new Queen(Side.WHITE);
		Queen blackQueen = new Queen(Side.BLACK);
		Knight whiteKnight = new Knight(Side.WHITE);
		Knight blackKnight = new Knight(Side.BLACK);
		Lancer whiteLancer = new Lancer(Side.WHITE);
		Lancer blackLancer = new Lancer(Side.BLACK);
		board = new Board();
		getBoard().set(new Pawn(Side.WHITE), 6, 0);
		getBoard().set(new Pawn(Side.WHITE), 6, 1);
		getBoard().set(new Pawn(Side.WHITE), 6, 2);
		getBoard().set(new Pawn(Side.WHITE), 6, 3);
		getBoard().set(new Pawn(Side.WHITE), 6, 4);
		getBoard().set(new Pawn(Side.WHITE), 6, 5);
		getBoard().set(new Pawn(Side.WHITE), 6, 6);
		getBoard().set(new Pawn(Side.WHITE), 6, 7);
		getBoard().set(new Pawn(Side.BLACK), 1, 0);
		getBoard().set(new Pawn(Side.BLACK), 1, 1);
		getBoard().set(new Pawn(Side.BLACK), 1, 2);
		getBoard().set(new Pawn(Side.BLACK), 1, 3);
		getBoard().set(new Pawn(Side.BLACK), 1, 4);
		getBoard().set(new Pawn(Side.BLACK), 1, 5);
		getBoard().set(new Pawn(Side.BLACK), 1, 6);
		getBoard().set(new Pawn(Side.BLACK), 1, 7);
		getBoard().set(whiteRook, 7, 0);
		getBoard().set(whiteRook2, 7, 7);
		getBoard().set(blackRook, 0, 0);
		getBoard().set(blackRook2, 0, 7);
		getBoard().set(blackBishop, 0, 2);
		getBoard().set(blackBishop, 0, 5);
		getBoard().set(whiteBishop, 7, 2);
		getBoard().set(whiteBishop, 7, 5);
		getBoard().set(whiteQueen, 7, 3);
		getBoard().set(blackQueen, 0, 3);
		getBoard().set(whiteKnight, 7, 1);
		getBoard().set(whiteKnight, 7, 6);
		getBoard().set(blackKnight, 0, 1);
		getBoard().set(blackKnight, 0, 6);
		getBoard().set(new King(Side.WHITE), 7, 4);
		getBoard().set(new King(Side.BLACK), 0, 4);

		System.out.println(getBoard());

		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				createAndShowGUI();
			}
		});
	}

	public static Board getBoard() {
		return board;
	}

	public Piece getPiece(int rank, int file) {
		return board.getPiece(rank, file);
	}

}

