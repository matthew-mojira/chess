package game;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import game.Movements.Movement;
import pieces.*;

public class Board implements Iterable<Piece> {

	public static final int BOARD_SIZE = 8;

	Piece[][] board;
	Piece[][] boardBackup;
	public Side sideToMove;
	public int moveCounter;

	Board() {
		board = new Piece[BOARD_SIZE][BOARD_SIZE];
		sideToMove = Side.WHITE;
		moveCounter = 1;
	}

	/**
	 * Attempts to move a piece from one position to another position.
	 * <p>
	 * The move from fromX/fromY to toX/toY shall only occur if it constitutes a
	 * legal move. NOTE: To castle, the move should be made by selecting the King,
	 * and then selecting the Rook to castle with.
	 * 
	 * @param fromX
	 * @param fromY
	 * @param toX
	 * @param toY
	 * @return true if a move happened, false if a move did not happen
	 */
	public boolean move(int fromX, int fromY, int toX, int toY) {

		Piece fromPiece = this.getPiece(fromX, fromY);
		Piece toPiece = this.getPiece(toX, toY);

		if (fromPiece == null || fromPiece.getSide() != sideToMove) {
			return false;
		}

		if (fromPiece.generateLegalMoves(this, fromX, fromY).checkLegalMove(toX, toY)) {

			// Make a backup of the board.

			boardBackup = new Piece[board.length][];
			for (int i = 0; i < board.length; i++) {
				boardBackup[i] = Arrays.copyOf(board[i], board[i].length);
			}

			// Castling logic
			if (fromPiece instanceof King
					&& fromPiece.generateLegalMoves(this, fromX, fromY).get(toX, toY) == Movement.CASTLE) {
				if (!this.isInCheck()) {
					board[toX][toY * 2 / 7 + 3] = toPiece;
					board[toX][toY] = null;
					board[fromX][toY * 4 / 7 + 2] = fromPiece;
					board[fromX][fromY] = null;
				} else {
					board = boardBackup;
					return false;
				}
			}

			// En Passant.
			if (fromPiece instanceof Pawn
					&& fromPiece.generateLegalMoves(this, fromX, fromY).get(toX, toY) == Movement.EN_PASSANT) {
				Pawn p = (Pawn)this.getPiece(toX + ((sideToMove == Side.WHITE) ? 1 : -1), toY);
				if (p.vulnerableToEnPassant) {
					board[toX + ((sideToMove == Side.WHITE) ? 1 : -1)][toY] = null;
				}
			}
			
			boolean flag = false;
			if (fromPiece.generateLegalMoves(this, fromX, fromY).get(toX, toY) == Movement.CAN_BE_EN_PASSANTED) {
				flag = true;
			}
			
			// We will try to make the requested move, and then see if this puts the player into check.
			board[toX][toY] = board[fromX][fromY];
			toPiece = fromPiece;
			board[fromX][fromY] = null;
			fromPiece = null;

			if (this.isPuttingOneSelfIntoCheck()) {
				board = boardBackup;
				return false;
			}

			// TOTALLY VALID herein

			// Pawn promotion
			if (toPiece instanceof Pawn && (toX == 0 || toX == 7)) {
				board[toX][toY] = new Queen(toPiece.getSide());
			}
			


			// Castling
			if (toPiece instanceof Rook) {
				Rook r = (Rook) (toPiece);
				r.disableRightToCastle();
			} else if (toPiece instanceof King) {
				King r = (King) (toPiece);
				r.disableRightToCastle();
			}

			// En passant.
			for (Piece[] a : board) {
				for (Piece c : a) {
					if (c instanceof Pawn) {
						Pawn p = ((Pawn)c);
						if (p.getSide() != sideToMove) {
							p.vulnerableToEnPassant = false;
						}
					}
				}
			}
			
			if (flag) {
				((Pawn)toPiece).vulnerableToEnPassant = true;
			}


			// Switch sides
			sideToMove = (sideToMove == Side.WHITE) ? Side.BLACK : Side.WHITE;
			if (sideToMove == Side.WHITE) {
				System.out.println("It is now move " + ++moveCounter);
			}

			return true;
		} else {
			return false;
		}

	}

	/**
	 * Directly returns the piece that is on the board at a certain position.
	 * 
	 * @param rank
	 * @param file
	 * @return the piece that is at the specified rank and file. If there is no
	 *         piece there, or the specified rank and file are out of bounds, this
	 *         returns null.
	 */
	public Piece getPiece(int rank, int file) {
		try {
			return board[rank][file];
		} catch (ArrayIndexOutOfBoundsException e) {
			return null;
		}
	}

	private boolean isPuttingOneSelfIntoCheck() {
		for (int i = 0; i < BOARD_SIZE; i++) {
			for (int j = 0; j < BOARD_SIZE; j++) {
				if (getPiece(i, j) == null || getPiece(i, j).getSide() == sideToMove) {
					continue;
				} else if (getPiece(i, j).attackingKing(this, i, j)) {
					return true;
				}
			}
		}
		return false;
	}

	// Basically we're in check if by doing nothing, we put ourself in check. That would
	// imply that we were in check the whole time because nothing happened and we are
	// now in check.
	public boolean isInCheck() {
		return isPuttingOneSelfIntoCheck();
	}

	public Movement simulateMove(int fromX, int fromY, int toX, int toY) {



		Piece fromPiece = this.getPiece(fromX, fromY);
		Piece toPiece = this.getPiece(toX, toY);

		if (fromPiece == null || fromPiece.getSide() != sideToMove) {
			return Movement.ILLEGAL;
		}

		if (fromPiece.generateLegalMoves(this, fromX, fromY).checkLegalMove(toX, toY)) {

			// Make a backup of the board.

			boardBackup = new Piece[board.length][];
			for (int i = 0; i < board.length; i++) {
				boardBackup[i] = Arrays.copyOf(board[i], board[i].length);
			}


			// We will try to make the requested move, and then see if this puts the player into check.
			board[toX][toY] = board[fromX][fromY];
			toPiece = fromPiece;
			board[fromX][fromY] = null;
			fromPiece = null;

			if (this.isPuttingOneSelfIntoCheck()) {
				board = boardBackup;
				return Movement.ILLEGAL;
			}

			sideToMove = (sideToMove == Side.WHITE) ? Side.BLACK : Side.WHITE;

			if (this.isInCheck()) {
				sideToMove = (sideToMove == Side.WHITE) ? Side.BLACK : Side.WHITE;
				board = boardBackup;
				return Movement.CHECK;
			}

			sideToMove = (sideToMove == Side.WHITE) ? Side.BLACK : Side.WHITE;




			board = boardBackup;



			return this.getPiece(fromX, fromY).generateLegalMoves(this, fromX, fromY).get(toX, toY);
		} else {
			return Movement.ILLEGAL;
		}


	}

	@Override
	public String toString() {
		String toString = "";
		for (int i = 0; i < board.length; i++) {
			for (int x = 0; x < 2 * BOARD_SIZE + 1; x++) {
				toString += "-";
			}
			toString += "\n";
			toString += "|";
			for (int j = 0; j < BOARD_SIZE; j++) {

				if (board[i][j] == null) {
					toString += " ";
				} else {
					toString += board[i][j].toString();
				}
				toString += "|";
			}
			toString += "\n";
		}
		for (int x = 0; x < 2 * BOARD_SIZE + 1; x++) {
			toString += "-";
		}
		toString += "\n";
		toString += sideToMove + " to move.";
		return toString;
	}

	private Piece[][] getBoard() {
		// TODO: avoid privacy leak
		return this.board;
	}

	void set(Piece p, int x, int y) {
		board[x][y] = p;
	}

	@Override
	public Iterator<Piece> iterator() {

		List<Piece> a = new ArrayList<>();
		// oh dear
		for (Piece[] p1 : board) {
			for (Piece p : p1) {
				a.add(p);
			}
		}

		return a.iterator();

	}

	public void undo() {
		board = boardBackup;

	}

}
