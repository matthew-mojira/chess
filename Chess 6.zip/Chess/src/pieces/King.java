package pieces;

import game.Board;
import game.Chess;
import game.Movements;
import game.Movements.Movement;
import pieces.Piece.Direction;

public class King extends Piece {

	private static final String WHITE_STRING = "\u2654";
	private static final String BLACK_STRING = "\u265A";

	private boolean rightToCastle;

	public King(Side side) {
		super(side);
		rightToCastle = true;
	}

	public void disableRightToCastle() {
		rightToCastle = false;
	}

	@Override
	public String toString() {
		return (this.getSide() == Side.WHITE) ? WHITE_STRING : BLACK_STRING;
	}

	@Override
	public Movements generateLegalMoves(Board b, int x, int y) {
		Movements m = new Movements();
		raycast(m, x, y, b, Direction.UP_LEFT, 1);
		raycast(m, x, y, b, Direction.UP_RIGHT, 1);
		raycast(m, x, y, b, Direction.DOWN_LEFT, 1);
		raycast(m, x, y, b, Direction.DOWN_RIGHT, 1);
		raycast(m, x, y, b, Direction.UP, 1);
		raycast(m, x, y, b, Direction.RIGHT, 1);
		raycast(m, x, y, b, Direction.LEFT, 1);
		raycast(m, x, y, b, Direction.DOWN, 1);

		// Check for castling.
//		if (!Chess.getBoard().isInCheck()) {	// hackfix. cannot castle out of check.
			if (rightToCastle && (b.getPiece(x, y - 1) == null && b.getPiece(x, y - 2) == null) && b.getPiece(x, y - 3) == null && b.getPiece(x, y - 4) instanceof Rook) {
				Rook r = (Rook)b.getPiece(x, y - 4);
				if (r.getRightToCastle() && !isEnemiesWith(b, x, y)) {
					m.set(x, y - 4, Movement.CASTLE);
				}
			} else if (rightToCastle && (b.getPiece(x, y + 1) == null && b.getPiece(x, y + 2) == null) && b.getPiece(x, y + 3) instanceof Rook) {
				Rook r = (Rook)b.getPiece(x, y + 3);
				if (r.getRightToCastle() && !isEnemiesWith(b, x, y)) {
					m.set(x, y + 3, Movement.CASTLE);
				}
			}
//		}


		return m;

	}


	private void castle() {
		throw new UnsupportedOperationException();
	}

}
