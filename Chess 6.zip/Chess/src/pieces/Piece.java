package pieces;

import game.Movements.*;
import game.Board;
import game.Movements;


public abstract class Piece {

	private static final String WHITE_STRING = null;
	private static final String BLACK_STRING = null;
	/*
	 * We rely on the Unicode set of characters for chess pieces. As such, it is
	 * hard to make new chess pieces because we need a Unicode set of characters
	 * that exist nicely in both white and black variants. The ones that I have
	 * found thus far to work well are:
	 * 
	 * https://www.unicode.org/charts/PDF/U2600.pdf
	 * https://www.unicode.org/charts/PDF/U1FA00.pdf
	 * 
	 */
	private Side side;

	public Piece(Side side) {
		this.side = side;
	}

	@Override
	public abstract String toString();

	/**
	 * Determines all the legal moves that this chess piece may take.
	 * 
	 * @param b the current board setup
	 * @param x the x-position of this piece (rank)
	 * @param y the y-position of this piece (file)
	 * @return 
	 */
	public abstract Movements generateLegalMoves(Board b, int x, int y);

	/**
	 * Determines if this piece is attacking the enemy king.
	 * 
	 * @param b the current board setup
	 * @param x the x-position of this piece (rank)
	 * @param y the y-position of this piece (file)
	 * @return whether or not this piece is attacking the enemy king
	 */
	@Deprecated
	public final boolean attackingKing(game.Board b, int x, int y) {
		return this.generateLegalMoves(b, x, y).hasCheck();
	}

	public final Side getSide() {
		return this.side;
	}

	public final boolean isEnemiesWith(Board b, int targetRank, int targetFile) {
		try {
			return b.getPiece(targetRank, targetFile).getSide() != this.getSide();
		} catch (NullPointerException e) {
			return false;
		}
	}

	public enum Direction {
		UP_LEFT(-1,-1), UP_RIGHT(-1,1), DOWN_LEFT(1,-1), DOWN_RIGHT(1,1), UP(-1,0), DOWN(1,0), LEFT(0,-1), RIGHT(0,1);

		int rankIncrement, fileIncrement;

		private Direction(int rankIncrement, int fileIncrement) {
			this.rankIncrement = rankIncrement;
			this.fileIncrement = fileIncrement;
		}
	}

	protected final Movements raycast(Movements input, int rank, int file, Board b, Direction d) {
		return raycast(input, rank, file, b, d, Board.BOARD_SIZE);
	}

	protected final Movements raycast(Movements input, int rank, int file, Board b, Direction d, int length) {
		if (input == null) {
			input = new Movements();
		}

		int rankIncrement = d.rankIncrement;
		int fileIncrement = d.fileIncrement;


		for (int i = 0; i < length; i++) {
			rank += rankIncrement;
			file += fileIncrement;

			if (b.getPiece(rank, file) == null) {
				input.set(rank, file, Movement.LEGAL);
			} else if (this.isEnemiesWith(b, rank, file)) {
				if (b.getPiece(rank, file) instanceof King) {
					input.set(rank, file, Movement.CHECK);
				} else {
					input.set(rank, file, Movement.CAPTURE);
				}
				break;
			} else {
				break;
			}
		}

		return input;
	}



}
