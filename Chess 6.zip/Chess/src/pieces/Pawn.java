package pieces;

import game.Board;
import game.Movements;
import game.Movements.*;

public class Pawn extends Piece {

	public boolean vulnerableToEnPassant;

	private static final String WHITE_STRING = "\u2659";
	private static final String BLACK_STRING = "\u265F";

	public Pawn(Side s) {
		super(s);
	}

	@Override
	public Movements generateLegalMoves(Board b, int rank, int file) {
		Movements m = new Movements();

		int doublyForward = rank + ((this.getSide() == Side.WHITE) ? -2 : 2);
		int rankForward = rank + ((this.getSide() == Side.WHITE) ? -1 : 1);

		// check if pawn can attack

		if (isEnemiesWith(b, rankForward, file - 1)) {
			if (b.getPiece(rankForward, file - 1) instanceof King) {
				m.set(rankForward, file - 1, Movement.CHECK);
			} else {
				m.set(rankForward, file - 1, Movement.CAPTURE);
			}
		}

		if (isEnemiesWith(b, rankForward, file + 1)) {
			if (b.getPiece(rankForward, file + 1) instanceof King) {
				m.set(rankForward, file + 1, Movement.CHECK);
			} else {
				m.set(rankForward, file + 1, Movement.CAPTURE);
			}
		}

		// check if Pawn can move forward

		if (b.getPiece(rankForward, file) == null) {
			m.set(rankForward, file, Movement.LEGAL);
			// move forward 2 from starting file. Note that a white pawn on 6th file cannot
			// move forward 2 spaces so we don't have to check based on color.
			if ((rank == 6 || rank == 1) && b.getPiece(doublyForward, file) == null) {
				m.set(doublyForward, file, Movement.CAN_BE_EN_PASSANTED);
			}
		}

		// check if Pawn can en passant
		// There are quite a lot of assumptions we can make if en passant is being
		// checked, but most of them have been ignored here.

		if (b.getPiece(rank, file - 1) instanceof Pawn && isEnemiesWith(b, rank, file - 1)) {
			Pawn p = (Pawn) b.getPiece(rank, file - 1);
			if (p.vulnerableToEnPassant) {
				m.set(rankForward, file - 1, Movement.EN_PASSANT);
			}
		}
		if (b.getPiece(rank, file + 1) instanceof Pawn && isEnemiesWith(b, rank, file + 1)) {
			Pawn p = (Pawn) b.getPiece(rank, file + 1);
			if (p.vulnerableToEnPassant) {
				m.set(rankForward, file + 1, Movement.EN_PASSANT);
			}
		}

		return m;

	}

	public String toString() {
		return (this.getSide() == Side.WHITE) ? WHITE_STRING : BLACK_STRING;
	}

	boolean enPassant() {
		throw new UnsupportedOperationException();
	}

}
