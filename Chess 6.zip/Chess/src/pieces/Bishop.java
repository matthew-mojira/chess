package pieces;

import game.Board;
import game.Movements;
import game.Movements.*;

public class Bishop extends Piece {
	
	private static final String WHITE_STRING = "\u2657";
	private static final String BLACK_STRING = "\u265D";

	public Bishop(Side side) {
		super(side);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return (this.getSide() == Side.WHITE) ? WHITE_STRING : BLACK_STRING;
	}

	@Override
	public Movements generateLegalMoves(Board b, int x, int y) {
		Movements m = new Movements();
		raycast(m, x, y, b, Direction.UP_LEFT);
		raycast(m, x, y, b, Direction.UP_RIGHT);
		raycast(m, x, y, b, Direction.DOWN_LEFT);
		raycast(m, x, y, b, Direction.DOWN_RIGHT);
		return m;
	}


}
