package pieces;

import game.Board;
import game.Movements;
import pieces.Piece.Direction;

public class Rook extends Piece {
	
	private static final String WHITE_STRING = "\u2656";
	private static final String BLACK_STRING = "\u265C";
	
	private boolean rightToCastle;

	public Rook(Side side) {
		super(side);
		rightToCastle = true;
		// TODO Auto-generated constructor stub
	}
	
	public void disableRightToCastle() {
		rightToCastle = false;
	}

	@Override
	public String toString() {
		return (this.getSide() == Side.WHITE) ? WHITE_STRING : BLACK_STRING;
	}

	@Override
	public Movements generateLegalMoves(Board b, int x, int y) {
		Movements m = new Movements();
		raycast(m, x, y, b, Direction.UP);
		raycast(m, x, y, b, Direction.RIGHT);
		raycast(m, x, y, b, Direction.LEFT);
		raycast(m, x, y, b, Direction.DOWN);
		return m;
	}
	
	public boolean getRightToCastle() {
		return rightToCastle;
	}


}
