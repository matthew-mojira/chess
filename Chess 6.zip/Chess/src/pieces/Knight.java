package pieces;

import game.Board;
import game.Movements;
import game.Movements.*;

public class Knight extends Piece {

	private static final String WHITE_STRING = "\u2658";
	private static final String BLACK_STRING = "\u265E";

	public Knight(Side side) {
		super(side);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return (this.getSide() == Side.WHITE) ? WHITE_STRING : BLACK_STRING;
	}

	/**
	 * Helps determine the legality of moves.
	 * 
	 * @param b
	 * @param newX
	 * @param newY
	 * @param m
	 */
	private void lawyer(Board b, int newX, int newY, Movements m) {
		if (b.getPiece(newX, newY) == null) {
			m.set(newX, newY, Movement.LEGAL);
		}

		if (isEnemiesWith(b, newX, newY)) {
			if (b.getPiece(newX, newY) instanceof King) {
				m.set(newX, newY, Movement.CHECK);
			} else {
				m.set(newX, newY, Movement.LEGAL);
			}
		}
	}

	@Override
	public Movements generateLegalMoves(Board b, int x, int y) {
		Movements m = new Movements();

		lawyer(b, x - 2, y - 1, m);
		lawyer(b, x - 2, y + 1, m);
		lawyer(b, x + 2, y - 1, m);
		lawyer(b, x + 2, y + 1, m);
		lawyer(b, x - 1, y - 2, m);
		lawyer(b, x - 1, y + 2, m);
		lawyer(b, x + 1, y - 2, m);
		lawyer(b, x + 1, y + 2, m);


		return m;

	}


}
