package pieces;

import game.Board;
import game.Movements;
import pieces.Piece.Direction;

/*
 * This is a totally custom piece! Radical!!!
 */
public class Lancer extends Piece {

	private static final String WHITE_STRING = "\u2664";
	private static final String BLACK_STRING = "\u2660";

	public Lancer(Side side) {
		super(side);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return (this.getSide() == Side.WHITE) ? WHITE_STRING : BLACK_STRING;
	}

	@Override
	public Movements generateLegalMoves(Board b, int x, int y) {
		Movements m = new Movements();
		raycast(m, x, y, b, Direction.UP_LEFT, 2);
		raycast(m, x, y, b, Direction.UP, 2);
		raycast(m, x, y, b, Direction.DOWN, 2);
		raycast(m, x, y, b, Direction.DOWN_RIGHT, 2);
		return m;
	}

}
