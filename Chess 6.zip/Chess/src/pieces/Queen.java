/**
 * 
 */
package pieces;

import game.Board;
import game.Movements;
import pieces.Piece.Direction;

/**
 * @author Matthew
 *
 */
public class Queen extends Piece {

	private static final String WHITE_STRING = "\u2655";
	private static final String BLACK_STRING = "\u265B";

	public Queen(Side side) {
		super(side);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return (this.getSide() == Side.WHITE) ? WHITE_STRING : BLACK_STRING;
	}

	@Override
	public Movements generateLegalMoves(Board b, int x, int y) {
		Movements m = new Movements();
		raycast(m, x, y, b, Direction.UP_LEFT);
		raycast(m, x, y, b, Direction.UP_RIGHT);
		raycast(m, x, y, b, Direction.DOWN_LEFT);
		raycast(m, x, y, b, Direction.DOWN_RIGHT);
		raycast(m, x, y, b, Direction.UP);
		raycast(m, x, y, b, Direction.RIGHT);
		raycast(m, x, y, b, Direction.LEFT);
		raycast(m, x, y, b, Direction.DOWN);
		return m;
	}


}
