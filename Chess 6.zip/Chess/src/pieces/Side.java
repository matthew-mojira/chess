package pieces;

public enum Side {

	WHITE, BLACK;
	
}
