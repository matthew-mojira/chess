package engines;

import java.awt.Component;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import game.Chess;
import game.Movements.Movement;

public class RandomEngine2 implements Chessable {

	private static final int BREAK_THRESHOLD = 1048576; // after this many moves, we think there is stalemate or
															// checkmate
	// situation so stop the randomizer from making more moves
	private static final int CHECK_ATTEMPTS = 1000;
	private static final int CAPTURE_ATTEMPTS = 10000;

	public RandomEngine2() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void makeAMove() {
		Random r = new Random();

		int counter = 1;

		// try to check the opponent
		for (int i = 0; i < CHECK_ATTEMPTS; i++) {
			counter++;
			int a = r.nextInt(8), b = r.nextInt(8), c = r.nextInt(8), d = r.nextInt(8);
			if (Chess.getBoard().simulateMove(a, b, c, d) == Movement.CHECK) {
				if (!Chess.getBoard().move(a, b, c, d)) {
					continue;
				} else {
					System.out.println(counter);
					return;
				}
			}
		}

		// try to capture a piece
		for (int i = 0; i < CAPTURE_ATTEMPTS; i++) {
			counter++;
			int a = r.nextInt(8), b = r.nextInt(8), c = r.nextInt(8), d = r.nextInt(8);
			if (Chess.getBoard().simulateMove(a, b, c, d) == Movement.CAPTURE
					&& (!(Chess.getBoard().getPiece(c, d) instanceof pieces.Pawn)
					|| ((Chess.getBoard().getPiece(c, d) instanceof pieces.Pawn)
							&& (Chess.getBoard().getPiece(a, b) instanceof pieces.Pawn)))) {
				
				// a piece should try not to capture a pawn unless it is a pawn
				
				if (!Chess.getBoard().move(a, b, c, d)) {
					continue;
				} else {
					System.out.println(counter);
					return;
				}
			}
		}

		// ok just make a move PLEASE!

		while (!Chess.getBoard().move(r.nextInt(8), r.nextInt(8), r.nextInt(8), r.nextInt(8))) {
			counter++;
			if (counter == BREAK_THRESHOLD) {
				System.out.println("Failed to find a valid move after " + counter + " attempts.");
				
				if (Chess.getBoard().isInCheck()) {
					JOptionPane.showMessageDialog(new JFrame(),
						    "Move maker failed to find a valid move. My guess is that " + Chess.getBoard().sideToMove + " has been checkmated.",
						    "Checkmate",
						    JOptionPane.PLAIN_MESSAGE);
				} else {
					JOptionPane.showMessageDialog(new JFrame(),
							"Move maker failed to find a valid move. My guess is that this is a stalemate.",
						    "Stalemate",
						    JOptionPane.PLAIN_MESSAGE);
				}

				
				return;
			}
		}

		System.out.println(counter);

	}

}
